<?php

namespace App\Http\Livewire\CommercialTeam\Tracker;

use App\Traits\HasTabs;

use Livewire\Component;
use App\Traits\UseOrderBy;

use App\Traits\ParseMonths;
use App\Traits\UseLocation;
use App\Traits\WithExportDate;
use App\Traits\HasInfinityScroll;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use App\Traits\StreamExcelDownload;
use App\Interface\Excel\WithFormatting;
use App\Interface\Excel\UseExcelDataset;

class AllCardRecon extends Component implements UseExcelDataset, WithFormatting {

    use HasInfinityScroll, HasTabs, WithExportDate, ParseMonths, UseOrderBy, UseLocation;


    /**
     * Filtering main data
     * @var
     */
    public $filtering = false;


    /**
     * Date from
     * @var
     */
    public $startDate = null;


    /**
     * TO date
     * @var
     */
    public $endDate = null;

    /**
     * Filename for export
     * @var string
     */
    public $export_file_name = 'Payment_MIS_COMMERCIAL_TEAM_Tracker_All_Tender_Reconciliation';


    /**
     * Active tab
     * @var string
     */
    public $activeTab = 'card';


    /**
     * Store Id to search for
     * @var
     */
    public $storeUID;

    /**
     * User id which i dont really use
     * @var
     */
    public $userUID;






    /**
     * Card Banks
     * @var array
     */
    public $stores = [];


    /**
     * Filters for Wallet
     * @var array
     */
    public $locations = [];


    public $store = '';


    public $status = '';
    public $Location = '';




    /**
     * Quering the search url
     * @var array
     */
    protected $queryString = [
        'activeTab' => ['as' => 'tab'],
        'startDate' => ['as' => 'from', 'except' => ''],
        'endDate' => ['as' => 'to', 'except' => ''],
    ];



    /**
     * Initializ the component
     * @return void
     */
    public function mount() {
        $this->reset();
        $this->stores = $this->_stores();
        $this->locations = $this->_location();
        $this->_months = $this->_months()->toArray();
    }


    public function render() {
        $dataset = $this->getData();
        $_totals = $this->getTotals();


        return view('livewire.commercial-team.tracker.all-card-recon', [
            'dataset' => $dataset,
            '_totals' => $_totals
        ]);
    }


    public function headers(): array {

        return [
            "Sales Date",
            "Deposit Date",
            "Store ID",
            "Retek Code",

            "Card Sales",
            "UPI Sales",
            "Wallet Sales",
            "Cash Sales",
            "Total Sales",

            "Card Collection",
            "UPI Collection",
            "Wallet Collection",
            "Cash Collection",
            "Total Collection",

            "Card Store Reponse",
            "UPI Store Reponse",
            "Wallet Store Reponse",
            "Cash Store Reponse",
            "Total Store Reponse",

            "Card Difference",
            "UPI Difference",
            "Wallet Difference",
            "Cash Difference",
            "Total Difference",
            "Status"
        ];
    }

    /**
     * Reload the filters
     * @return void
     */
    public function back() {
        $this->emit('resetAll');
        $this->resetExcept('activeTab');
    }



    /**
     *Filters
     */
    public function filterDate($request) {
        $this->startDate = $request['start'];
        $this->endDate = $request['end'];
        $this->filtering = true;
    }




    /**
     * Get totals
     * @return array
     */
    public function getTotals() {

        $params = [
            'procType' => 'get_totals',
            'store' => $this->store,
            'status' => $this->status,
            'location' => $this->Location,
            'from' => $this->startDate,
            'to' => $this->endDate
        ];

        return DB::withOrderBySelect(
            'PaymentMIS_PROC_SELECT_COMMERCIALTEAM_Tracker_All_Card_Reconciliation :procType, :store, :status, :location, :from, :to',
            $params,
            $this->perPage,
            $this->orderBy
        );
    }


    /**
     * Data source
     * @return array
     */
    public function getData() {

        $params = [
            'procType' => 'all',
            'store' => $this->store,
            'status' => $this->status,
            'location' => $this->Location,
            'from' => $this->startDate,
            'to' => $this->endDate
        ];

        return DB::withOrderBySelect(
            'PaymentMIS_PROC_SELECT_COMMERCIALTEAM_Tracker_All_Card_Reconciliation :procType, :store, :status, :location, :from, :to',
            $params,
            $this->perPage,
            $this->orderBy
        );
    }

    public function download(string $value): Collection|bool {
        $params = [
            'procType' => 'export',
            'store' => $this->store,
            'status' => $this->status,
            'location' => $this->Location,
            'from' => $this->startDate,
            'to' => $this->endDate
        ];


        return DB::withOrderBySelect(
            'PaymentMIS_PROC_SELECT_COMMERCIALTEAM_Tracker_All_Card_Reconciliation :procType, :store, :status,:location, :from, :to',
            $params,
            perPage: $this->perPage,
            orderBy: $this->orderBy
        );
    }




    public function export() {

        $data = $this->download('');
        $headers = $this->headers();
        $_totals = $this->getTotals();

        $filePath = public_path() . '/' . $this->export_file_name . '.csv';
        $file = fopen($filePath, 'w'); // open the filePath - create if not exists

        fputcsv($file, ['Total Count: ', $_totals[0]->TotalCount]);
        fputcsv($file, ['Matched Count: ', $_totals[0]->MatchedCount]);
        fputcsv($file, ['Not Matched Count: ', $_totals[0]->NotMatchedCount]);
        fputcsv($file, ['']);


        // DINSX
        fputcsv($file, ['', '', '', 'Total', '', '', '', '', $_totals[0]->sales_totalF, '', '', '', '', $_totals[0]->collection_totalF, '', '', '', '', $_totals[0]->adjustment_totalF, '', '', '', '', $_totals[0]->difference_totalF]);

        fputcsv($file, $headers);

        foreach ($data as $row) {
            $row = (array) $row;
            fputcsv($file, $row);
        }

        fclose($file);

        return response()->stream(
            function () use ($filePath) {
                echo file_get_contents($filePath);
            },
            200,
            [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => 'attachment;filename="' . $this->export_file_name . '"',
            ]
        );
    }


    public function formatter(\App\Interface\Excel\SpreadSheet $worksheet, $dataset): void {

        $worksheet->setStartFrom(9);
        $worksheet->setFilename($this->_useToday($this->export_file_name, now()->format('d-m-Y')));

        $_totals = $this->getTotals();

        // headings
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('A' . 2, 'Total Calculations');

        $worksheet->spreadsheet->getActiveSheet()
            ->getStyle('A2:A2')
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setARGB('3682cd');


        $worksheet->spreadsheet->getActiveSheet()->setCellValue('A' . 3, 'Total Count: ' . $_totals[0]->TotalCount);
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('A' . 4, 'Matched Count: ' . $_totals[0]->MatchedCount);
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('A' . 5, 'Not Matched Count: ' . $_totals[0]->NotMatchedCount);

        $worksheet->spreadsheet->getActiveSheet()->setCellValue('D7', 'Total: ');
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('I7', $_totals[0]->sales_totalF);
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('N7', $_totals[0]->collection_totalF);
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('S7', $_totals[0]->adjustment_totalF);
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('X7', $_totals[0]->difference_totalF);

        $worksheet->spreadsheet->getActiveSheet()->getStyle('A2:A5')->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

        $worksheet->spreadsheet->getActiveSheet()->getStyle('A2:A5')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

        $worksheet->spreadsheet->getActiveSheet()->setCellValue('E' . 8, 'Sales');
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('J' . 8, 'Collection');
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('O' . 8, 'Store Response Entry');
        $worksheet->spreadsheet->getActiveSheet()->setCellValue('T' . 8, 'Difference');
        $worksheet->spreadsheet->getActiveSheet()->mergeCells('E8:I8');
        $worksheet->spreadsheet->getActiveSheet()->mergeCells('J8:N8');
        $worksheet->spreadsheet->getActiveSheet()->mergeCells('O8:S8');
        $worksheet->spreadsheet->getActiveSheet()->mergeCells('T8:Y8');

        // adding border
        $worksheet->spreadsheet->getActiveSheet()->getStyle('A8:Y8')->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

        // background color

        $worksheet->spreadsheet->getActiveSheet()
            ->getStyle('E8:I8')
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setARGB('04364A');

        $worksheet->spreadsheet->getActiveSheet()
            ->getStyle('J8:N8')
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setARGB('176B87');


        $worksheet->spreadsheet->getActiveSheet()
            ->getStyle('O8:S8')
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setARGB('DAFFFB');

        $worksheet->spreadsheet->getActiveSheet()
            ->getStyle('T8:Y8')
            ->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()
            ->setARGB('176B87');


        $worksheet->spreadsheet->getActiveSheet()
            ->getStyle('E8:N8')
            ->getFont()
            ->getColor()
            ->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_WHITE);


        $worksheet->spreadsheet->getActiveSheet()->getStyle('A8:Y8')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    }
}
