<section id="topcust2" style="margin-bottom: 2vh">
    {{-- <div class="card shadow"> --}}
    {{-- <div class="card-body"> --}}
    <div class="row">
        {{ $slot }}
    </div>
    {{-- </div> --}}
    {{-- </div> --}}
</section>
