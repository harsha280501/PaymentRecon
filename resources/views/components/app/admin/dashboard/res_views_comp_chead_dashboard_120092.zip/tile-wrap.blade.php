<div class="card" id="dash">
    {{-- Headers --}}
    {{ $slot }}
    <div style="text-align: right;"><a class="btn btn-success" href="tracker">View More</a></div>
</div>
